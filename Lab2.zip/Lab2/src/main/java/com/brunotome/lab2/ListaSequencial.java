/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.brunotome.lab2;
import java.util.*;
/**
 *
 * @author brunorosa
 */
public class ListaSequencial extends Lista{
    private IElemento[] data = {null};
    ListaSequencial(){ 
        this.tamanho();
            }
    
    
    @Override
    public int tamanho() {
        int cont = 0;
        int i = 0;
        while(data[i]!=null){cont++;}
        this.tamanho = cont;
        return this.tamanho;
    }

    @Override
    public void inserir(IElemento elem) {
       int i = 0;
       while(!java.util.Objects.equals(null, data[i])){
           i++;
       }
       data[i] = elem;
       
    }

    @Override
    public void remover(IElemento elem) {
        int i = 0 ;
        while(i <= tamanho){
            if(java.util.Objects.equals(data[i], elem)){
                data[i] = null;
            }else{i++;}
        }
    }

    @Override
    public void imprimir() {
        
        int i = 0;
        while(i <= tamanho){
            System.out.println("#:" + i + " data:" + data[i]);
            i++;
            
        }
    }
    
}
